var app = angular.module('expensesApp', []);

app.controller('ExpensesViewController', ['$scope', function($scope) {
    $scope.items =[
        {
            name: 'pizza',
            ingredients: ['cheese', 'tomato', 'oregano','salt']
        }
    ]
}])
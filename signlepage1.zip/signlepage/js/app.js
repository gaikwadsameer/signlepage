var app = angular.module('expensesApp', []);

app.controller('ExpensesViewController', ['$scope', function($scope){
    $scope.name = 'Pablo';
}])